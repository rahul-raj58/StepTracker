package com.example.steptracker
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.ProgressBar
import android.widget.TextView

// Data class representing a stop with its name and distance
class Stop(val name: String, val distance: Double)
class MainActivity : AppCompatActivity() {
    // Views
    private lateinit var stopsTextView: TextView
    private lateinit var distanceTextView: TextView
    private lateinit var totalDistanceCoveredTextView: TextView
    private lateinit var totalDistanceLeftTextView: TextView
    private lateinit var progressBar: ProgressBar
    private lateinit var switchUnitsButton: Button
    private lateinit var nextStopButton: Button
    // Variables
    private var currentStopIndex = 0

//  Lazy initialization for the list of stops
    private val journey: List<Stop> by lazy {
        mutableListOf<Stop>().apply {
            // Add at least 10 stops here
            for (i in 1..15) {
                add(Stop("Stop $i", i * 5.0)) // Distance in kilometers
            }
        }
    }
    private var isKilometers = true
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
// Initialize views
        stopsTextView = findViewById(R.id.stopsTextView)
        distanceTextView = findViewById(R.id.distanceTextView)
        totalDistanceCoveredTextView = findViewById(R.id.totalDistanceCoveredTextView)
        totalDistanceLeftTextView = findViewById(R.id.totalDistanceLeftTextView)
        progressBar = findViewById(R.id.progressBar)
        switchUnitsButton = findViewById(R.id.switchUnitsButton)
        nextStopButton = findViewById(R.id.nextStopButton)
// Set click listeners
        switchUnitsButton.setOnClickListener { switchUnits() }
        nextStopButton.setOnClickListener { nextStopReached() }
        // Update UI with initial data
        updateUI()
    }

    // Function to switch between kilometers and miles
    private fun switchUnits() {
// Switch between kilometers and miles
        isKilometers = !isKilometers
        updateUI()
    }
    // Function to handle reaching the next stop
    private fun nextStopReached() {
        currentStopIndex++
        updateUI()
    }
    // Function to update UI elements based on the current stop
    private fun updateUI() {
        if (currentStopIndex < journey.size) {
            val currentStop = journey[currentStopIndex]
            stopsTextView.text = getString(R.string.stop_text, currentStop.name)

            val distance = if (isKilometers) currentStop.distance else convertToMiles(currentStop.distance)
            val unitLabel = if (isKilometers) "km" else "miles"
            val distanceText = "Distance: $distance $unitLabel"
            distanceTextView.text = distanceText

            val totalDistanceCovered = calculateTotalDistanceCovered()
            val totalDistanceCoveredText = "Total distance covered: ${formatDistance(totalDistanceCovered)}"
            totalDistanceCoveredTextView.text = totalDistanceCoveredText

            val totalDistanceLeft = calculateTotalDistanceLeft()
            val totalDistanceLeftText = "Total distance left: ${formatDistance(totalDistanceLeft)}"
            totalDistanceLeftTextView.text = totalDistanceLeftText

            progressBar.progress = calculateProgress()
        } else {
// Journey completed
            stopsTextView.setText(R.string.journey_completed_message)

            distanceTextView.text = ""
            totalDistanceCoveredTextView.text = ""
            totalDistanceLeftTextView.text = ""
            progressBar.progress = progressBar.max
        }
    }
    // Function to calculate total distance covered
    private fun calculateTotalDistanceCovered(): Double {
        var totalDistanceCovered = 0.0
        for (i in 0 until currentStopIndex) {
            totalDistanceCovered += journey[i].distance
        }
        return totalDistanceCovered
    }
    // Function to calculate total distance left
    private fun calculateTotalDistanceLeft(): Double {
        var totalDistanceLeft = 0.0
        for (i in currentStopIndex until journey.size) {
            totalDistanceLeft += journey[i].distance
        }
        return totalDistanceLeft
    }
    // Function to calculate progress for the progress bar
    private fun calculateProgress(): Int {
        val totalDistance = journey.sumOf { it.distance }

        val totalDistanceCovered = calculateTotalDistanceCovered()
        return ((totalDistanceCovered / totalDistance) * progressBar.max).toInt()
    }
    // Function to convert kilometers to miles
    private fun convertToMiles(kilometers: Double): Double {
        return kilometers * 0.621371
    }
    // Function to format distance text
    private fun formatDistance(distance: Double): String {
        return if (isKilometers) "$distance km" else "${String.format("%.2f", distance)} miles"
    }
}